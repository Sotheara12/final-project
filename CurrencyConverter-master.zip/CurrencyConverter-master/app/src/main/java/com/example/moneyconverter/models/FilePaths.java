package com.example.moneyconverter.models;

public final class FilePaths {
    public static final String API_DATA = "apiData.api";
}
